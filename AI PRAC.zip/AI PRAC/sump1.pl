sum:-write("Enter the first no."),read(A),
    write("Enter the second no."),read(B),
    C is A+B,
    write("The sum of two numbers are :-"),write(C).

