multi(N1,N2,R):- R is N1*N2.

