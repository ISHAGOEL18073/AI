evelength([]).
evelength([_|[_|List]]):- evelength(List).
oddlen([_]).
oddlen([_|[_|List]]):- oddlen(List).
