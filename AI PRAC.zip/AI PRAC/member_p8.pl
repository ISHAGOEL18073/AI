memb(X,[X|_]).
memb(X,[Y|L]):- memb(X,L).
