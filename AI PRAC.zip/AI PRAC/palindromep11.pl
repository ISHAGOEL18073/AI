append([],L,L).
append([X|L1],L2,[X|L3]):- append(L1,L2,L3).
palindrome([]).
palindrome([_]).
palindrome(L):-append([H|T],[H],L),palindrome(T).
